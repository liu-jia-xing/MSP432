/*��Ŀ��飺��*/
#include <msp430f169.h>
#include "OLED.h"
#define CPU_F ((double)8000000)   //�ⲿ��Ƶ����8MHZ
//#define CPU_F ((double)32768)   //�ⲿ��Ƶ����32.768KHZ
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))
#define uchar unsigned char
#define uint unsigned int
unsigned int time1=0,time2=0;
unsigned int time=0;
unsigned int cishu=0;
double speed=0;
unsigned char cc=0;
float x;
unsigned char start=0;
unsigned int licheng=0;
unsigned char val[];
void Clock_Init()
{
  uchar i;
  BCSCTL1&=~XT2OFF;                 //��XT2����
  BCSCTL2|=SELM1+SELS;              //MCLKΪ8MHZ��SMCLKΪ8MHZ
  do{
    IFG1&=~OFIFG;                   //������������־
    for(i=0;i<100;i++)
       _NOP();
  }
  while((IFG1&OFIFG)!=0);           //�����־λ1�������ѭ���ȴ�
  IFG1&=~OFIFG;
}
/***********************************
 * ��������:ʵ�ֶ�ʱ��A��PWM��ʼ��
 * �Ĵ���ѡ��:TACCTL1
 ***********************************/
void TimeA_init(){
    TACTL |=TASSEL_1+MC_1;        //ѡ��ACLK��Ϊ��ʱ��A��ʱ�ӣ�����Ƶ����������ģʽ;
    TACCTL1=CM_1+CCIS_0+CAP+SCS+CCIE;   //ѡ�������½��ض�����(CM_1:�����ز���CM_2:�½��ز���)
    TACCTL0=CCIE;
    TACCR0=2000;//����Դ:CCI1A,����ģʽ,ͬ������,�����ж�����
}
void write_SegA (unsigned int value)
{
  unsigned char *Flash_ptr;                          // Flash pointer
//  unsigned int i;
  Flash_ptr = (unsigned char *) 0x1080;              // Initialize Flash pointer
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
  FCTL3 = FWKEY;                            // Clear Lock bit
  *Flash_ptr = 0;                           // Dummy write to erase Flash segment
  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation
  *Flash_ptr=(value>>8);
  Flash_ptr++;
  *Flash_ptr=(value&0xff);
                                  // Write value to flash
  FCTL1 = FWKEY;                            // Clear WRT bit
  FCTL3 = FWKEY + LOCK;                     // Set LOCK bit
}

unsigned char read_SegA(unsigned int address)
{   unsigned char data;
    char *Flash_ptrA;
    Flash_ptrA = (char *) 0x1080;
    Flash_ptrA+=address;
    data=* Flash_ptrA;
    return data;
}
void port_init(){
     P1SEL |=BIT2;                      //ѡ��P1.2�ڶ����ܽ�:��ʱ��A����CCI1A����;
     P3DIR |=BIT1;                      //P1.1������Ϊ���ģʽ
     P6DIR=0xff;
     P6OUT=0xff;
     P3OUT =BIT1;
}
/*
 * main.c
 */
void main(void)
{
//    unsigned int a;
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    TimeA_init();
    Clock_Init();
    port_init();                        //�˿ڳ�ʼ��
    _EINT();                            //�����ж�
    OLED_Init();
    OLED_Clear();
    OLED_write_str(0,0,"�ٶ�:000.00 Km/h");
    OLED_write_str(0,2,"���:         m");
  //  licheng+=read_SegA(0)<<8;
   // P6OUT =~read_SegA(0);
   delay_ms(2);
//    licheng+=read_SegA(1);
    while(1)
    {   if(start==1){
        if(cc<2)
        speed=20933*3.6/(time*2);
//            speed=30000*3.6/time;
        else
        {   speed=0;
//            a=(unsigned int)(licheng+0.6*cishu);
//            write_SegA(a);
            start=0;
        }
        OLED_ShowChar(40,0,(unsigned char)speed%1000/100+'0');
        OLED_ShowChar(48,0,(unsigned char)speed%1000%100/10+'0');
        OLED_ShowChar(56,0,(unsigned char)speed%100%10+'0');
        x=speed -(unsigned int)speed;
        speed *=100;
        OLED_ShowChar(72,0,(unsigned char)speed/100+'0');
        OLED_ShowChar(80,0,(unsigned char)speed%100/10+'0');
      //  licheng=cishu*0.6;
        OLED_ShowString(40,2,int2str(cishu*0.6+licheng));
     }
   }
}

#pragma vector =TIMERA1_VECTOR
__interrupt void ceju()
{
    switch(TAIV)
    {
    case 0x02:
        cishu++;
        start=1;
      //  P6OUT=~cishu;
        if(time1==0)
        {
            time1=TACCR1;
           }
        else
        {
            time2=TACCR1;
            if(time2>time1){
                time=time2-time1;
            }
            else{
                time=time2+(65535-time1);
                TACCR1=0;
                }
            time1=0;
            cc=0;
        }
    break;
    case 0x04:break;
    case 0x10:P6OUT ^=BIT0;break;
    }
}

#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A (void)
{
    cc++;                     // Toggle P1.0
}

