/*
 * OLED.c
 *
 *  Created on: 2018��12��11��
 *      Author: liu
 */

#include "OLED.h"

void oled_init()
{
        i2c_write(0x00,0xAE);//--turn off oled panel
        i2c_write(0x00,0x00);//---set low column address
        i2c_write(0x00,0x10);//---set high column address
        i2c_write(0x00,0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
        i2c_write(0x00,0x81);//--set contrast control register
        i2c_write(0x00,0xCF); // Set SEG Output Current Brightness
        i2c_write(0x00,0xA1);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
        i2c_write(0x00,0xC8);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
        i2c_write(0x00,0xA6);//--set normal display
        i2c_write(0x00,0xA8);//--set multiplex ratio(1 to 64)
        i2c_write(0x00,0x3f);//--1/64 duty
        i2c_write(0x00,0xD3);//-set display offset   Shift Mapping RAM Counter (0x00~0x3F)
        i2c_write(0x00,0x00);//-not offset
        i2c_write(0x00,0xd5);//--set display clock divide ratio/oscillator frequency
        i2c_write(0x00,0x80);//--set divide ratio, Set Clock as 100 Frames/Sec
        i2c_write(0x00,0xD9);//--set pre-charge period
        i2c_write(0x00,0xF1);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
        i2c_write(0x00,0xDA);//--set com pins hardware configuration
        i2c_write(0x00,0x12);
        i2c_write(0x00,0xDB);//--set vcomh
        i2c_write(0x00,0x40);//Set VCOM Deselect Level
        i2c_write(0x00,0x10);//-Set Page Addressing Mode (0x00/0x01/0x02)
        i2c_write(0x00,0x02);//
        i2c_write(0x00,0x8D);//--set Charge Pump enable/disable
        i2c_write(0x00,0x14);//--set(0x10) disable
        i2c_write(0x00,0xA4);// Disable Entire Display On (0xa4/0xa5)
        i2c_write(0x00,0xA6);// Disable Inverse Display On (0xa6/a7)
        i2c_write(0x00,0xAF);//--turn on oled panel
        i2c_write(0x00,0xAF); /*display ON*/
}
//����
void OLED_Clear(void)
{
    unsigned char i,n;
    for(i=0;i<8;i++)
    {
        i2c_write(0x00,0xb0+i);    //����ҳ��ַ��0~7��
        i2c_write(0x00,0x00);      //������ʾλ�á��е͵�ַ
        i2c_write(0x00,0x10);      //������ʾλ�á��иߵ�ַ
        for(n=0;n<128;n++)i2c_write(0x40,0x00);
    } //������ʾ
}
//������ʾλ��
void OLED_Set_Pos(unsigned char x, unsigned char y)
{
    i2c_write(0x00,0xb0+y);
    i2c_write(0x00,((x&0xf0)>>4)|0x10);
    i2c_write(0x00,(x&0x0f)|0x01);
}

/*��������:д��������
 * ��������:������:x,������:y,��:font
 * 16*16����
 * */
void fonts_display(unsigned char x,unsigned y,unsigned char font)
{   unsigned char a;
    x=x*16;
    font*=2;
    OLED_Set_Pos(x,y);                  //�����ַ���λ��
    for(a=0;a<16;a++)
    i2c_write(0x40,shuzu[font][a]);     //�ϰ���
    OLED_Set_Pos(x,y+1);
    for(a=0;a<16;a++)                   //�°���
    i2c_write(0x40,shuzu[font+1][a]);
}
//��ʾ�����ַ�
void OLED_ShowChar(unsigned char x,unsigned char  y,unsigned char chr)
{
    unsigned char c=0,i=0;
        c=chr-' ';//
        if(x>Max_Column-1){x=0;y=y+2;}
        if(SIZE==16)
            {
            OLED_Set_Pos(x,y);
            for(i=0;i<8;i++)
            i2c_write(0x40,F8X16[c*16+i]);
            OLED_Set_Pos(x,y+1);
            for(i=0;i<8;i++)
            i2c_write(0x40,F8X16[c*16+i+8]);
            }
        else {
            OLED_Set_Pos(x,y+1);
            for(i=0;i<6;i++)
                i2c_write(0x40,F6x8[c][i]);
        }
}
//m^n
unsigned long oled_pow(unsigned char  m,unsigned char n)
{
    unsigned long result=1;
    while(n--)result*=m;
    return result;
}

void OLED_ShowNum(unsigned char x,unsigned char y,unsigned long num,unsigned char len,unsigned char size)
{
    unsigned char t,temp;
    unsigned char enshow=0;
    for(t=0;t<len;t++)
    {
        temp=(num/oled_pow(10,len-t-1))%10;
        if(enshow==0&&t<(len-1))
        {
            if(temp==0)
            {
                OLED_ShowChar(x+(size/2)*t,y,' ');
                continue;
            }else enshow=1;

        }
        OLED_ShowChar(x+(size/2)*t,y,temp+'0');
    }
}
void OLED_write_char(unsigned char x,unsigned char y,unsigned char str[2])
{   unsigned char a,b;
    OLED_Set_Pos(x,y);
    for(a=0;a<72;a++)
    {
        if((Fonts16x16[a].Index[0]==str[0])&&(Fonts16x16[a].Index[1]==str[1]))
        {
            for(b=0;b<16;b++)
                i2c_write(0x40,Fonts16x16[a].Msk[b]);     //�ϰ���
            OLED_Set_Pos(x,y+1);
            for(b=0;b<16;b++)                   //�°���
                i2c_write(0x40,Fonts16x16[a].Msk[b+16]);
        }
    }
}

void OLED_write_str(unsigned char x,unsigned char y,unsigned char *str)
{
   // unsigned char i,j;
    while(*str)
    {   if( *str < 0x80)
    {
        OLED_ShowChar(x,y,*str);
        x+=8;str++;
    }
    else
    {   OLED_write_char(x,y,str);
        x+=8;str++;}
    }
}
unsigned char * int2str(unsigned int num)
{
   unsigned char temp;
   static unsigned char result[1024] = {0};
   unsigned int i = 0;
   unsigned int len = 0;
   while(num != 0)
    {
       result[i] = (num  % 10) + '0' ;
         num= num / 10;
         i++;
    }
   result[i] = '\0';
   len = strlen(result);
   for(i = 0; i < len / 2; i++)
    {
       temp = result[i];
         result[i]= result[len - 1 - i];
         result[len- 1 - i] = temp;
    }
   return result;
}
